package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.BaseDAO;

public class BookServlet extends HttpServlet {
	BaseDAO dao = new BaseDAO();
	public void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String dest = "/book/show.jsp";
		String operate = request.getParameter("operate");
		if ("add".equals(operate)) {
			String no = request.getParameter("no");
			String name = request.getParameter("name");
			String press = request.getParameter("press");
			int num = Integer.parseInt(request.getParameter("num"));

			dao.operate("insert into book values(null,?,?,?,?)",new Object[] {no,name,press,num});
		}
		if ("del".equals(operate)) {
			int id = Integer.parseInt(request.getParameter("id"));
			dao.operate("delete from book where id=" + id, null);
		}
		if ("modify".equals(operate)) {
			int id = Integer.parseInt(request.getParameter("id"));
			Object[] data = dao.findSingle("select * from book where id="+id, null);
			request.setAttribute("data",data);
			dest = "/book/modify.jsp";
		}

		if ("update".equals(operate)) {
			String no = request.getParameter("no");
			String name = request.getParameter("name");
			String press = request.getParameter("press");
			int num = Integer.parseInt(request.getParameter("num"));
			int id = Integer.parseInt(request.getParameter("id"));
			dao.operate("update book set no=?,name=?,press=?,num=?  where id=?",new Object[] {no,name,press,num,id});
		}
		

		List all = dao.find("select * from book", null);
		request.setAttribute("all", all);
	
		request.getRequestDispatcher(dest).forward(request,response);

	}
}
