package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.BaseDAO;

public class ReportServlet extends HttpServlet {

	BaseDAO dao = new BaseDAO();

	public void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
        String operate = request.getParameter("operate");
        if("borrow".equals(operate)){
        	List all = dao.find("select name,count(*),sum(num) from borrow group by name", null);
        	request.setAttribute("all", all);
        	request.getRequestDispatcher("/data/borrow.jsp").forward(request,response);
        }
        if("back".equals(operate)){
        	List all = dao.find("select name,count(*),sum(num) from back group by name", null);
        	request.setAttribute("all", all);
        	request.getRequestDispatcher("/data/back.jsp").forward(request,response);
        }
	}

}
