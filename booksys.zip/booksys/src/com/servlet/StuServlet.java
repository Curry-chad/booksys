package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.BaseDAO;

public class StuServlet extends HttpServlet {
	BaseDAO dao = new BaseDAO();
	public void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String dest = "/stu/show.jsp";
		String operate = request.getParameter("operate");
		if ("add".equals(operate)) {
			String no = request.getParameter("no");
			String name = request.getParameter("name");
			String team = request.getParameter("team");
			String tel = request.getParameter("tel");

			dao.operate("insert into stu values(null,?,?,?,?,?)",new Object[] {no,name,team,tel,"111111"});
		}
		if ("del".equals(operate)) {
			int id = Integer.parseInt(request.getParameter("id"));
			dao.operate("delete from stu where id=" + id, null);
		}
		if ("modify".equals(operate)) {
			int id = Integer.parseInt(request.getParameter("id"));
			Object[] data = dao.findSingle("select * from stu where id="+id, null);
			request.setAttribute("data",data);
			dest = "/stu/modify.jsp";
		}
		
		if ("edit".equals(operate)) {
			int id = Integer.parseInt(request.getParameter("id"));
			Object[] data = dao.findSingle("select * from stu where id="+id, null);
			request.setAttribute("data",data);
			dest = "/stu/edit.jsp";
		}
		
		if ("update".equals(operate)) {
			String no = request.getParameter("no");
			String name = request.getParameter("name");
			String tel = request.getParameter("tel");
			String team = request.getParameter("team");
			String pwd = request.getParameter("pwd");
			int id = Integer.parseInt(request.getParameter("id"));
			dao.operate("update stu set no=?,name=?,tel=?,team=?,pwd=? where id=?",new Object[] {no,name,tel,team,pwd,id});
		}
		
		if ("change".equals(operate)) {
			int id = Integer.parseInt(request.getParameter("id"));
			Object[] data = dao.findSingle("select * from stu where id="+id, null);
			String oldPwd = (String)data[5];
			String old = request.getParameter("old");
			String pwd = request.getParameter("pwd");
			String confirm = request.getParameter("confirm");
			
			if(!oldPwd.equals(old)){
				request.setAttribute("msg","旧密码输入不正确!");
			}else if(!pwd.equals(confirm)){
				request.setAttribute("msg","两次输入的密码不一致!");
			}else{
				dao.operate("update stu set pwd=? where id=?",new Object[] {pwd,id});
				request.setAttribute("msg","密码修改成功!");
			}
		}
		
		String role =(String)request.getSession().getAttribute("role");
		if("学生".equals(role)){
			Object[] data = (Object[])request.getSession().getAttribute("loginUser");
			List all = dao.find("select * from stu where no=?",new Object[]{data[1]});
			request.setAttribute("all", all);
		}else{
			List all = dao.find("select * from stu", null);
			request.setAttribute("all", all);
		}
		request.getRequestDispatcher(dest).forward(request,response);

	}
}
