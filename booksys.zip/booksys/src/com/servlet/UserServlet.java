package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.dao.BaseDAO;

public class UserServlet extends HttpServlet {
	BaseDAO dao = new BaseDAO();

	public void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String operate = request.getParameter("operate");
		if("login".equals(operate)){
			String name = request.getParameter("name");
			String pwd = request.getParameter("pwd");
			String role = request.getParameter("role");
	
			if ("学生".equals(role)) {
				Object[] data = dao.findSingle("select * from stu where no=? and pwd=?", new Object[] {name, pwd });
				if (data != null) {
					request.getSession().setAttribute("role", role);
					request.getSession().setAttribute("loginUser", data);
					request.getRequestDispatcher("/index.jsp").forward(request,response);
				} else {
					request.getRequestDispatcher("/login.jsp").forward(request,response);
				}
			} else {
					Object[] data = dao.findSingle("select * from userinfo where name=? and pwd=? and role=?",new Object[] { name, pwd,role});
					if (data != null) {
						request.getSession().setAttribute("role", role);
						request.getSession().setAttribute("loginUser", data);
						request.getRequestDispatcher("/index.jsp").forward(request,response);
					} else {
						request.getRequestDispatcher("/login.jsp").forward(request,response);
					}
				}
		}
		
        
        if("add".equals(operate)){
    		String name = request.getParameter("name");
    		String pwd = request.getParameter("pwd");
    		dao.operate("insert into userinfo values(null,?,?,?)", new Object[]{name,pwd,"操作员"});
    		
    		List all = dao.find("select * from userinfo", null);
    		request.setAttribute("all", all);
    		request.getRequestDispatcher("/userinfo/show.jsp").forward(request,response);
        }
        if("del".equals(operate)){
        	int id = Integer.parseInt(request.getParameter("id"));
    		dao.operate("delete from userinfo where id="+id, null);
    		
    		List all = dao.find("select * from userinfo", null);
    		request.setAttribute("all", all);
    		request.getRequestDispatcher("/userinfo/show.jsp").forward(request,response);
        }
        if("modify".equals(operate)){
			int id = Integer.parseInt(request.getParameter("id"));
			Object[] data = dao.findSingle("select * from userinfo where id="+id, null);
			request.setAttribute("data",data);
			request.getRequestDispatcher("/userinfo/modify.jsp").forward(request,response);
        }
        if("update".equals(operate)){
    		String name = request.getParameter("name");
    		String pwd = request.getParameter("pwd");
    		int id = Integer.parseInt(request.getParameter("id"));
    		dao.operate("update userinfo set name=?,pwd=? where id="+id, new Object[]{name,pwd});
    		
    		request.getRequestDispatcher("/userServlet?operate=show").forward(request,response);
        }
        if("show".equals(operate)){
    		String role =(String)request.getSession().getAttribute("role");
    		if("操作员".equals(role)){
    			Object[] data = (Object[])request.getSession().getAttribute("loginUser");
    		    List all = dao.find("select * from userinfo where id=?", new Object[]{data[0]});
    		    request.setAttribute("all", all);
    		    request.getRequestDispatcher("/userinfo/show.jsp").forward(request,response);
    		}else{
    		    List all = dao.find("select * from userinfo", null);
    		    request.setAttribute("all", all);
    		    request.getRequestDispatcher("/userinfo/show.jsp").forward(request,response);
    		}
        }
	}

}
