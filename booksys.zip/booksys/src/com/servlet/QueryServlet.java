package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.BaseDAO;
import java.util.*;
public class QueryServlet extends HttpServlet {
    BaseDAO dao = new BaseDAO();
	public void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		   List paramList = new ArrayList();
           String operate = request.getParameter("operate");
           if("borrow".equals(operate)){
        	   String sql = "select * from borrow where 1=1";
        	   String stuname = request.getParameter("stuname");
        	   String start = request.getParameter("start");
        	   String over = request.getParameter("over");
        	   if(!"".equals(stuname)){
        		   sql+=" and stuname=?";
        		   paramList.add(stuname);
        		   
        	   }
        	   if(!"".equals(start) && !"".equals(over)){
        		   sql+=" and (curtime>=? and curtime<=?)";
        		   paramList.add(start);
        		   paramList.add(over);
        		   
        	   }
        	   List all = dao.find(sql,paramList.toArray());
        	   request.setAttribute("all", all);
        	   request.getRequestDispatcher("/report/borrow.jsp").forward(request,response);
           }
           if("back".equals(operate)){
        	   String sql = "select * from back where 1=1";
        	   String stuname = request.getParameter("stuname");
        	   String start = request.getParameter("start");
        	   String over = request.getParameter("over");
        	   if(!"".equals(stuname)){
        		   sql+=" and stuname=?";
        		   paramList.add(stuname);
        		   
        	   }
        	   if(!"".equals(start) && !"".equals(over)){
        		   sql+=" and (curtime>=? and curtime<=?)";
        		   paramList.add(start);
        		   paramList.add(over);
        		   
        	   }
        	   List all = dao.find(sql,paramList.toArray());
        	   request.setAttribute("all", all);
        	   request.getRequestDispatcher("/report/back.jsp").forward(request,response);
           }
	}

}
