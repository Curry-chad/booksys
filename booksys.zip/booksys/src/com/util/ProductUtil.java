package com.util;

import com.dao.BaseDAO;

public class ProductUtil {
	BaseDAO dao = new BaseDAO();
	Object[] data = null;

	public Object[] findByNO(String no) {
		try {
            data = dao.findSingle("select * from book where no=?", new Object[]{no});
		} catch (Exception e) {
			e.printStackTrace();
		}
		return data;
	}
	
	public Object[] findNO(String no) {
		try {
            data = dao.findSingle("select * from borrow where no=?", new Object[]{no});
		} catch (Exception e) {
			e.printStackTrace();
		}
		return data;
	}
}
